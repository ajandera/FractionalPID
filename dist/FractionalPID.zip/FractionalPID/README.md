# FractionalPID

Arduino library to calculate u by fractional non linear PID controller.

## Description

This is a simple Arduino library used to demonstrate fractional PID non linear regulator developed by prof. Ing. Ivo Petras, Phd

This library example is basd on Matlab file exchange of Ivo Petras [Non-Linear Fractional-Order PID Controller](https://www.mathworks.com/matlabcentral/fileexchange/51190-non-linear-fractional-order-pid-controller).
